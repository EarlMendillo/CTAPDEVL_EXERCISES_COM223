package com.example.exercise2

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment

class fragment_user_page : Fragment() {

    private var username: String? = null

    private lateinit var profileImageView: ImageView
    private lateinit var gridImages: GridLayout

    private val pickProfileImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val selectedImageUri: Uri? = result.data?.data
            selectedImageUri?.let {
                profileImageView.setImageURI(it)
            }
        }
    }

    private val pickReelsImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val selectedImageUri: Uri? = result.data?.data
            selectedImageUri?.let {
                val imageView = ImageView(requireContext()).apply {
                    layoutParams = GridLayout.LayoutParams().apply {
                        width = 0
                        height = 300
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(2, 2, 2, 2)
                    }
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageURI(it)
                }
                gridImages.addView(imageView)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        username = arguments?.getString(ARG_USERNAME)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_user_page, container, false)

        // UI setup
        val usernameTextView: TextView = view.findViewById(R.id.username)
        usernameTextView.text = username

        profileImageView = view.findViewById(R.id.profile_picture)
        gridImages = view.findViewById(R.id.grid_images)
        val editProfileButton: Button = view.findViewById(R.id.edit_profile_button)
        val reelsImageView: ImageView = view.findViewById(R.id.ic_reels)

        editProfileButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK).apply {
                type = "image/*"
            }
            pickProfileImageLauncher.launch(intent)
        }

        reelsImageView.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK).apply {
                type = "image/*"
            }
            pickReelsImageLauncher.launch(intent)
        }

        return view
    }

    companion object {
        private const val ARG_USERNAME = "USERNAME"

        fun newInstance(username: String): fragment_user_page {
            val fragment = fragment_user_page()
            val args = Bundle()
            args.putString(ARG_USERNAME, username)
            fragment.arguments = args
            return fragment
        }
    }
}
