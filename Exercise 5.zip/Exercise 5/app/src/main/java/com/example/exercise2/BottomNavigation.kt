package com.example.exercise2

import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.exercise2.databinding.ActivityBottomNavigationBinding

class BottomNavigation : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bottom_navigation)

        val username = intent.getStringExtra("USERNAME") ?: ""

        val homeFragment = fragment_homepage.newInstance(username)
        val profileFragment = fragment_user_page.newInstance(username)


        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, homeFragment)
            .commit()

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomnavitems)
        bottomNav.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.navigation_home -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, fragment_homepage.newInstance(username))
                        .commit()
                    true
                }
                R.id.navigation_profile -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, fragment_user_page())
                        .commit()
                    true
                }
                else -> false
            }
        }
    }
}


