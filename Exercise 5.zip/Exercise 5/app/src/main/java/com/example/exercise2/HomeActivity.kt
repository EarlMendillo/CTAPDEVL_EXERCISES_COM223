package com.example.instagramclone

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.exercise2.R

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.homepage)

        val usernameTextView = findViewById<TextView>(R.id.username)
        val username = intent.getStringExtra("USERNAME") ?: "Guest"
        usernameTextView.text = "Welcome, $username!"
    }
}
