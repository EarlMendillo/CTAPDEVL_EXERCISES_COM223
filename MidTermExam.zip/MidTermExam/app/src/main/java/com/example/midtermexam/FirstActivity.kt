package com.example.midtermexam

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()
        println("activity 1 has started")
    }

    override fun onResume() {
        super.onResume()
        println("activity 1 has resumed")
    }

    override fun onPause() {
        super.onPause()
        println("activity 1 has paused")
    }

    override fun onStop() {
        super.onStop()
        println("activity 1 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        println("activity 1 has been destroyed")
    }

    fun goToSecondActivity(view: View) {
        val inputText = findViewById<EditText>(R.id.editTextInput).text.toString()
        val intent = Intent(this, SecondActivity::class.java)
        intent.putExtra("input", inputText)
        startActivity(intent)

    }
}