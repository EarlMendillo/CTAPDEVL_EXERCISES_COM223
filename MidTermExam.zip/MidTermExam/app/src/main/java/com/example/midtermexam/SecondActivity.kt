package com.example.midtermexam

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val inputText = intent.getStringExtra("input")
        findViewById<TextView>(R.id.textViewInput).text = inputText
    }

    override fun onStart() {
        super.onStart()
        println("activity 2 has started")
    }

    override fun onResume() {
        super.onResume()
        println("activity 2 has resumed")
    }

    override fun onPause() {
        super.onPause()
        println("activity 2 has paused")
    }

    override fun onStop() {
        super.onStop()
        println("activity 2 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        println("activity 2 has been destroyed")
    }

    fun goToThirdActivity(view: View) {
        val inputText = findViewById<TextView>(R.id.textViewInput).text.toString()
        val intent = Intent(this, ThirdActivity::class.java)
        intent.putExtra("input2", inputText)
        startActivity(intent)
    }
}