package com.example.midtermexam

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val input = intent.getStringExtra("input2")
        findViewById<TextView>(R.id.textViewFinal).text = input
    }

    override fun onStart() {
        super.onStart()
        println("activity 2 has started")
    }

    override fun onResume() {
        super.onResume()
        println("activity 2 has resumed")
    }

    override fun onPause() {
        super.onPause()
        println("activity 2 has paused")
    }

    override fun onStop() {
        super.onStop()
        println("activity 2 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        println("activity 2 has been destroyed")
    }

    fun openGitHub(view: View) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/EarlMendillo"))
        startActivity(intent)
    }
}